package views;

import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import engine.Game;
import model.abilities.Ability;
import model.abilities.CrowdControlAbility;
import model.abilities.DamagingAbility;
import model.abilities.HealingAbility;
import model.world.Champion;

public class SecondPlayerPanel extends JPanel implements ActionListener, ListSelectionListener{

	private JLabel sPLabel;
	private JTextField sPField;
	private JList <String> sPList;
	private JButton sPButton;
	private JCheckBox sPCheck1;
	private JCheckBox sPCheck2;
	private JCheckBox sPCheck3;
	private ButtonGroup sPBGroup;
	private JTextArea sPArea;
	private JScrollPane scroll; 
	
	private MainJFrame MainJframe;
	
	private GamePanel gamePanel;


	
	public SecondPlayerPanel(MainJFrame MainJframe) {
		this.MainJframe=MainJframe;
		
		this.setVisible(true);
		this.setLayout(null);
		this.setBackground(Color.BLACK);
		
		sPLabel = new JLabel("Second Player Name:");
		sPLabel.setBounds(50, 140, 150, 35);
		this.add(sPLabel);
		sPLabel.setForeground(Color.WHITE);
		
		
		sPField = new JTextField();
		sPField.setBounds(250, 140, 150, 35);
		this.add(sPField);
		
		sPButton = new JButton("Start Game");
		sPButton.setBounds(520, 530, 150, 35);
		sPButton.setFont(new Font("Serif",Font.BOLD,15));
		this.add(sPButton);
		sPButton.addActionListener(this);
		
		sPCheck1 = new JCheckBox("1st selection will be leader");
		sPCheck1.setBackground(Color.BLACK);
		sPCheck1.setForeground(Color.WHITE);
		sPCheck1.setBounds(780, 110, 190, 20);
		this.add(sPCheck1);
		
		sPCheck2 = new JCheckBox("2nd selection will be leader");
		sPCheck2.setBackground(Color.BLACK);
		sPCheck2.setForeground(Color.WHITE);
		sPCheck2.setBounds(780, 260, 200, 20);
		this.add(sPCheck2);
		
		sPCheck3 = new JCheckBox("3rd selection will be leader");
		sPCheck3.setBackground(Color.BLACK);
		sPCheck3.setForeground(Color.WHITE);
		sPCheck3.setBounds(780, 410, 190, 20);
		this.add(sPCheck3);
		
		sPBGroup = new ButtonGroup();
		sPBGroup.add(sPCheck1);
		sPBGroup.add(sPCheck2);
		sPBGroup.add(sPCheck3);
		
		sPArea = new JTextArea("please select a champion from the list");
		sPArea.setEditable(false);
		scroll= new JScrollPane(sPArea);
		scroll.setBounds(50, 280, 300, 300);
		this.add(scroll);
		//sPArea.setBounds(50, 280, 300, 200);
		// this.add(sPArea);
		
		
		String [] availableChampionsA = MainJframe.getAvailableChampionsA();
		sPList = new JList <String>(availableChampionsA);
		sPList.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
		sPList.setBounds(450, 70, 300, 420);
		sPList.addListSelectionListener(this); 
		this.add(sPList);
		
	
		
	}
	
	
	@Override
	public void actionPerformed(ActionEvent e) {

		if(sPField.getText().equals("")) {
			JOptionPane.showMessageDialog(this, "please enter a player name", "ERROR",
					JOptionPane.ERROR_MESSAGE);	
		}
		else if ((sPList.getSelectedIndices().length)!=3) {
			JOptionPane.showMessageDialog(this, "Please select 3 Champions", "ERROR",
					JOptionPane.ERROR_MESSAGE);
		}
		else if(CheckifTwoTeamsDifferent()==false) {
			JOptionPane.showMessageDialog(this, "please select different champions than the firt player team : " 
		+ firstTeamNames(),
					"ERROR", JOptionPane.ERROR_MESSAGE);
		}
		
		else if (sPCheck1.isSelected()==false && sPCheck2.isSelected()==false && sPCheck3.isSelected()==false) {
			JOptionPane.showMessageDialog(this, "Please select one Champion as a leader", "ERROR",
					JOptionPane.ERROR_MESSAGE);
			
		}
		
		else {
			
			MainJframe.setSecondPlayerName(sPField.getText());
			MainJframe.secondPlayerTeamOfChampsMethod(sPList.getSelectedIndices());
			
			if(sPCheck1.isSelected()) {
				int index = sPList.getSelectedIndices()[0];
				MainJframe.setSLeader(MainJframe.getAvailableChampionsA()[index]);
			}
			else if(sPCheck2.isSelected()) {
				int index = sPList.getSelectedIndices()[1];
				MainJframe.setSLeader(MainJframe.getAvailableChampionsA()[index]);
			}
			else if(sPCheck3.isSelected()) {
				int index = sPList.getSelectedIndices()[2];
				MainJframe.setSLeader(MainJframe.getAvailableChampionsA()[index]);
			}
			
			switchToBoardPanelPanel();
			
			
		}
		
	}
	
	public boolean CheckifTwoTeamsDifferent() {
		boolean Flag= true;
		MainJframe.secondPlayerTeamOfChampsMethod(sPList.getSelectedIndices());
		ArrayList <Champion> c = MainJframe.getFirstPlayerTeamOfChamps();
		ArrayList <Champion> d = MainJframe.getSecondPlayerTeamOfChamps();
		
		for(int i=0; i<MainJframe.getFirstPlayerTeamOfChamps().size();i++) {
			for(int j=0; j< MainJframe.getSecondPlayerTeamOfChamps().size(); j++) {
				if(c.get(i).getName().equals(d.get(j).getName())) {
					Flag= false;
					break;
				}
			}
			
			if(Flag==false)
				break;
		}
		return Flag;
	}
	
	
	public String firstTeamNames() {
		String s = "";
		ArrayList <Champion> c = MainJframe.getFirstPlayerTeamOfChamps();
		
		for(int i=0; i<c.size(); i++) {
			s= s+ c.get(i).getName() + "\n" ;
		}
		return s;


	}
	
	
	public void switchToBoardPanelPanel() {
		
		this.setVisible(false);
		
		MainJframe.publishGame();
		
		gamePanel= new GamePanel(MainJframe);
		MainJframe.add(gamePanel);

		this.validate();
		this.repaint();
		
		
	}

	@Override
	public void valueChanged(ListSelectionEvent e) {

		int index = sPList.getAnchorSelectionIndex();
		ArrayList <Champion> list = Game.getAvailableChampions();
		Champion c = list.get(index);
	

		/*	String s= "Name: "+ c.getName() + "\n" + "MaxHP: " + c.getMaxHP() +"\n" +"CurrentHP" + c.getCurrentHP() +"\n" +
					"Mana: " + c.getMana()+"\n" + "maxActionPointsPerTurn: " + c.getMaxActionPointsPerTurn()+"\n" +
					"currentActionPoints: " + c.getCurrentActionPoints() +"\n" + "attackRange: "+ c.getAttackRange() +"\n" +
					"attackDamage: "+c.getAttackDamage()+"\n" + 
					"speed: "+c.getSpeed()+"\n\n" + "Abilities: " + "\n" ;
			for(int i=1; i<4;i++) {
				Ability a = c.getAbilities().get(i-1);
				s= s + (i)+ ")" +a.getName() + ":- " + "\n"+ "type:  " ; 
				if(a instanceof CrowdControlAbility) {
					s=s+ "CrowdControlAbility" + "\n"; 
				}
				else if(a instanceof HealingAbility) {
					s=s+ "HealingAbility"+ "\n"; 
				}
				else if(a instanceof DamagingAbility) {
					s=s+ "DamagingAbility" + "\n"; 
				} 
				
				s=s+ "area of affect: " + a.getCastArea() + "\n" + "cast range: " + a.getCastRange() + "\n" + 
				"ManaCost: " + a.getManaCost() + "\n" + "requiredActionPoints: " + a.getRequiredActionPoints()
				+ "\n" + "CurrentCoolDown: "+ a.getCurrentCooldown()+ "\n" + "BaseCoolDown: "+ a.getBaseCooldown()
				+ "\n" ;
				if(a instanceof CrowdControlAbility) {
					s=s+ "Effect Name: " + ((CrowdControlAbility) a).getEffect().getName() + ", Effect Duration: "+
					((CrowdControlAbility) a).getEffect().getDuration() + "\n\n"; 
				}
				else if(a instanceof HealingAbility) {
					s=s+ "Healing Amount: " + ((HealingAbility) a).getHealAmount()+ "\n\n"; 
				}
				else if(a instanceof DamagingAbility) {
					s=s+ "Damage Amount: " + ((DamagingAbility) a).getDamageAmount()+ "\n\n"; 
				}
				
			} */
			
			String s= "Name: "+ c.getName() + "\n" + "MaxHP: " + c.getMaxHP() +"\n" +"CurrentHP" + c.getCurrentHP() +"\n" +
					"Mana: " + c.getMana()+"\n" + "maxActionPointsPerTurn: " + c.getMaxActionPointsPerTurn()+"\n" +
					"currentActionPoints: " + c.getCurrentActionPoints() +"\n" + "attackRange: "+ c.getAttackRange() +"\n" +
					"attackDamage: "+c.getAttackDamage()+"\n" + 
					"speed: "+c.getSpeed()+"\n\n" + "Abilities: " + "\n" ;

			for(int i=1; i<4;i++) {
				Ability a = c.getAbilities().get(i-1);
				s= s + i+ ")" +a.getName() + ":- " + "\n"+ "type:  " ; 
				if(a instanceof CrowdControlAbility) {
					s=s+ "CrowdControlAbility" + "\n"; 
				}
				else if(a instanceof HealingAbility) {
					s=s+ "HealingAbility"+ "\n"; 
				}
				else if(a instanceof DamagingAbility) {
					s=s+ "DamagingAbility" + "\n"; 
				} 
				
				s=s+ "area of affect: " + a.getCastArea() + "\n" + "cast range: " + a.getCastRange() + "\n" + 
				"ManaCost: " + a.getManaCost() + "\n" + "requiredActionPoints: " + a.getRequiredActionPoints()
				+ "\n" + "CurrentCoolDown: "+ a.getCurrentCooldown()+ "\n" + "BaseCoolDown: "+ a.getBaseCooldown()
				+ "\n" ;
				if(a instanceof CrowdControlAbility) {
					s=s+ "Effect Name: " + ((CrowdControlAbility) a).getEffect().getName() + "\n" +"Effect Duration: "+
					((CrowdControlAbility) a).getEffect().getDuration() + "\n\n"; 
				}
				else if(a instanceof HealingAbility) {
					s=s+ "Healing Amount: " + ((HealingAbility) a).getHealAmount()+ "\n\n"; 
				}
				else if(a instanceof DamagingAbility) {
					s=s+ "Damage Amount: " + ((DamagingAbility) a).getDamageAmount()+ "\n\n"; 
				}
			}
			
			sPArea.setText(s);
			}
		
	}


