package views;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;

import javax.swing.JFrame;

import engine.Game;
import engine.Player;
import model.world.Champion;

public class MainJFrame extends JFrame {

	private	WelcomePlanel welcomepanel;
	
	private String firstPlayerName; 
	private String fLeader;
	private ArrayList<Champion> firstPlayerTeamOfChamps;
	private Champion firstPlayerLeader;
	Player firstPlayer1;
	
	private String secondPlayerName;
	private String sLeader;
	private ArrayList<Champion> secondPlayerTeamOfChamps;
	private Champion secondPlayerLeader;
	Player secondPlayer2 ;

	
	private String [] availableChampionsA;
	
	private Game game;

	
	
	public MainJFrame() {
		this.setSize(1000,700);
		this.setTitle("Marvel");
		this.setVisible(true);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		
		welcomepanel = new WelcomePlanel(this);
		this.add(welcomepanel);
		
		this.validate();
		this.repaint();
	}
	
	/*public void switchToFirstPlayerPanel() {
		
	}*/
	
	
	public static void main (String[]args) {
		MainJFrame MainFrame = new MainJFrame();
	}

	public String getFirstPlayerName() {
		return firstPlayerName;
	}

	public void setFirstPlayerName(String firstPlayerName) {
		this.firstPlayerName = firstPlayerName;
	}
	
	public void firstPlayerTeamOfChampsMethod(int [] t) {
		firstPlayerTeamOfChamps = new ArrayList <Champion>();
		for(int i=0; i<t.length;i++) {
			
			int index = t[i];
			Champion c = Game.getAvailableChampions().get(index);
			firstPlayerTeamOfChamps.add(c);
		}		
	}
	
	public ArrayList <Champion> getFirstPlayerTeamOfChamps(){
		return firstPlayerTeamOfChamps;
	}
	
	public void secondPlayerTeamOfChampsMethod(int [] t) {
		secondPlayerTeamOfChamps = new ArrayList <Champion>();
		for(int i=0; i<t.length;i++) {
			
			int index = t[i];
			Champion c = Game.getAvailableChampions().get(index);
			secondPlayerTeamOfChamps.add(c);
		}		
	}
	public ArrayList <Champion> getSecondPlayerTeamOfChamps(){
		return secondPlayerTeamOfChamps;
	}

	public String getSecondPlayerName() {
		return secondPlayerName;
	}

	public void setSecondPlayerName(String secondPlayerName) {
		this.secondPlayerName = secondPlayerName;
	}
	
	
	public void getavailableChampions() {
		
		try {
			Game.loadAbilities("Abilities.csv");
			Game.loadChampions("Champions.csv");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		ArrayList <Champion> L = Game.getAvailableChampions();
		availableChampionsA = new String [L.size()];
	

		for(int i=0; i<L.size();i++) {
			String ChampName = L.get(i).getName();
			availableChampionsA[i] = ChampName;

		}
	}
	
	public String [] getAvailableChampionsA() {
		return availableChampionsA;
	}

	public String getFLeader() {
		return fLeader;
	}

	public void setFLeader(String fLeader) {
		this.fLeader = fLeader;
	}

	public String getSLeader() {
		return sLeader;
	}

	public void setSLeader(String sLeader) {
		this.sLeader = sLeader;
	}

	public Game getGame() {
		return game;
	}

	public void setGame(Game game) {
		this.game = game;
	}
	
	
	/*
	 * private String firstPlayerName; 
	private String fLeader;
	private ArrayList<Champion> firstPlayerTeamOfChamps;
	
	private String secondPlayerName;
	private String sLeader;
	private ArrayList<Champion> secondPlayerTeamOfChamps;
	 */
	public void publishGame() {
		
		GetLeaders();
		
		firstPlayer1 = new Player(firstPlayerName);
		firstPlayer1.setLeader(firstPlayerLeader);
		for(int i=0; i<firstPlayerTeamOfChamps.size();i++) {
			firstPlayer1.getTeam().add(firstPlayerTeamOfChamps.get(i));
		}
		
		secondPlayer2 = new Player(secondPlayerName);
		secondPlayer2.setLeader(secondPlayerLeader);
		for(int i=0; i<secondPlayerTeamOfChamps.size();i++) {
			secondPlayer2.getTeam().add(secondPlayerTeamOfChamps.get(i));
		}
		
		game= new Game(firstPlayer1,secondPlayer2);
		
	}

	private void GetLeaders() {
		for(int i=0; i<Game.getAvailableChampions().size(); i++) {
			
			if(Game.getAvailableChampions().get(i).getName().equals(fLeader)) {
				firstPlayerLeader= Game.getAvailableChampions().get(i);
			}
		}
		
		for(int i=0; i<Game.getAvailableChampions().size(); i++) {
			
			if(Game.getAvailableChampions().get(i).getName().equals(sLeader)) {
				secondPlayerLeader= Game.getAvailableChampions().get(i);
			}
		}
	}

	public Champion getfirstPlayerLeader() {
		return firstPlayerLeader;
	}

	public Champion getsecondPlayerLeader() {
		return secondPlayerLeader;
	}
	
}
