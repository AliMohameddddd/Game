package views;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class WelcomePlanel extends JPanel implements ActionListener {

	private JLabel welcomelabel;
	private JButton yesB;
	private MainJFrame MainJframe;
	private JLabel introPicLabel;

	
	private FirstPlayerPanel firstPlayerPanel;
			
	public WelcomePlanel(MainJFrame MainJframe)  {
		
		this.MainJframe = MainJframe;
		
		this.setVisible(true);
		this.setLayout(null);
		this.setBackground(Color.RED);
		
	
		
		introPicLabel = new JLabel(new ImageIcon("avenger3.jpg"));
		introPicLabel.setBounds(0, 0, 1000, 700);
	//	this.add(introPicLabel);
		
		
		 
		
	/*	welcomelabel = new JLabel("Are you ready to experience the real MARVEL adventure?");
		welcomelabel.setFont(new Font("Serif", Font.PLAIN, 30));
		welcomelabel.setBounds(150, 140, 700, 70);
		this.add(welcomelabel);
		introPicLabel.add(welcomelabel);
	*/	
		
		JButton yesB = new JButton("PLAY");
		yesB.setFont(new Font("Serif",Font.BOLD,25));
		yesB.setBounds(400, 550, 200, 70);
		yesB.setBackground(Color.LIGHT_GRAY);
		yesB.setForeground(Color.BLACK);
	//	this.add(yesB);
		yesB.addActionListener(this);
	//	this.add(yesB);
		introPicLabel.add(yesB);
		
		this.add(introPicLabel);

		
		
	}
	public void switchToFirstPlayerPanel() {
		
		this.setVisible(false);
		
		firstPlayerPanel= new FirstPlayerPanel(MainJframe);
		MainJframe.add(firstPlayerPanel);
		
		this.validate();
		this.repaint();
	}
	

	@Override
	public void actionPerformed(ActionEvent e) {

		switchToFirstPlayerPanel();
	}
}

