package views;

import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.LayoutManager;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

import model.world.Champion;
import model.world.Cover;

public class BoardPanel extends JPanel implements ActionListener{

	private MainJFrame MainJframe; 
	private GamePanel gamePanel;

	private  JButton boardV [][]; 
	
	private JLabel c;

	
	
	

	public BoardPanel(MainJFrame MainJframe, GamePanel gamePanel) {
		this.MainJframe= MainJframe;
		this.gamePanel= gamePanel;
		
		this.setVisible(true);
		this.setLayout(new GridLayout(5, 5));

		boardV= new JButton[5][5];
		
		for(int i=0; i<5; i++) {
			for(int j=0; j<5 ;j++) {
				
				if(MainJframe.getGame().getBoard()[i][j] instanceof Cover) {
					ImageIcon icon = new ImageIcon("cover3.png");
					Cover g = (Cover)(MainJframe.getGame().getBoard()[i][j]);
					boardV [i][j] = new JButton("CurrentHP: "+g.getCurrentHP(),icon);
					boardV [i][j].setFont(new Font("Serif",Font.BOLD,9));
					boardV[i][j].setHorizontalTextPosition(JButton.CENTER);
					boardV[i][j].setVerticalTextPosition(JButton.CENTER);
					
				}
				else {
				boardV [i][j] = new JButton();
				}
				boardV[i][j].addActionListener(this);
				this.add(boardV[i][j]);
			}
		
		}
		updatedBoard(MainJframe);
	}
	
	

	/*public void putnamesofchamps() {
			if(MainJframe.getGame().getFirstPlayer().getTeam().contains(champ)) {
							if(MainJframe.getGame().getFirstPlayer().getLeader()==champ) {
								boardV[i][j].setBackground(Color.GRAY);
							}
							else {
						
								boardV[i][j].setBackground(Color.BLUE);
							}
							boardV[i][j].setText(champ.getName());
							boardV[i][j].setForeground(Color.WHITE);

					}
				if(MainJframe.getGame().getSecondPlayer().getTeam().contains(champ)) {
							if(MainJframe.getGame().getSecondPlayer().getLeader()==champ) {
								boardV[i][j].setBackground(Color.GRAY);
								}
						
					else {
							boardV[i][j].setBackground(Color.RED);
							
				}
							boardV[i][j].setText(champ.getName());
							boardV[i][j].setForeground(Color.WHITE);


				
			}
	}*/


	public void updatedBoard(MainJFrame MainJframe) {
		
	/*	for(int p=0; p<5; p++) {
			for(int k=0; k<5 ;k++) {
				if(MainJframe.getGame().getBoard()[p][k] instanceof Cover) {
					c= new JLabel();
					c.setSize(200, 30);
					c.setFont(new Font("Serif", Font.BOLD, 9));
					boardV[p][k].add(c);
				}
			}
		} */
		
		for(int i=0; i<5; i++) {
			for(int j=0; j<5 ;j++) {
		
				if(MainJframe.getGame().getBoard()[i][j] == null) {
					boardV[i][j].setIcon(new ImageIcon("null.jpg"));
					boardV[i][j].setText("");;
				}
				else if(MainJframe.getGame().getBoard()[i][j] instanceof Cover) {
					Cover g = (Cover)(MainJframe.getGame().getBoard()[i][j]);
					boardV[i][j].setText("CurrentHP: "+g.getCurrentHP());
					
				
				}
				
				else if(MainJframe.getGame().getBoard()[i][j] instanceof Champion) {
					Champion champ = (Champion) MainJframe.getGame().getBoard()[i][j];
					
					if(champ.getName().equals("Captain America")) {
						boardV[i][j].setIcon(new ImageIcon("CaptainAmerica.png"));
						boardV[i][j].setToolTipText("CurrentHP: "+champ.getCurrentHP());				

					}
					else if(champ.getName().equals("Deadpool")) {
						boardV[i][j].setIcon(new ImageIcon("deadpool.png"));
						boardV[i][j].setToolTipText("CurrentHP: "+champ.getCurrentHP());				


					}
					else if(champ.getName().equals("Dr Strange")) {
						boardV[i][j].setIcon(new ImageIcon("Drstrange.png"));
						boardV[i][j].setToolTipText("CurrentHP: "+champ.getCurrentHP());				

					}
					else if(champ.getName().equals("Electro")) {
						boardV[i][j].setIcon(new ImageIcon("Electro.jpg"));
						boardV[i][j].setToolTipText("CurrentHP: "+champ.getCurrentHP());				

					}
					else if(champ.getName().equals("Ghost Rider")) {
						boardV[i][j].setIcon(new ImageIcon("Ghostrider.png"));
						boardV[i][j].setToolTipText("CurrentHP: "+champ.getCurrentHP());				

					}
					else if(champ.getName().equals("Hela")) {
						boardV[i][j].setIcon(new ImageIcon("Hela.png"));
						boardV[i][j].setToolTipText("CurrentHP: "+champ.getCurrentHP());				

					}
					else if(champ.getName().equals("Hulk")) {
						boardV[i][j].setIcon(new ImageIcon("Hulk.jpg"));
						boardV[i][j].setToolTipText("CurrentHP: "+champ.getCurrentHP());				

					}
					else if(champ.getName().equals("Iceman")) {
						boardV[i][j].setIcon(new ImageIcon("Iceman.jpg"));
						boardV[i][j].setToolTipText("CurrentHP: "+champ.getCurrentHP());				

					}
					else if(champ.getName().equals("Ironman")) {
						boardV[i][j].setIcon(new ImageIcon("Ironman.jpg"));
						boardV[i][j].setToolTipText("CurrentHP: "+champ.getCurrentHP());				

					}
					else if(champ.getName().equals("Loki")) {
						boardV[i][j].setIcon(new ImageIcon("Loki.png"));
						boardV[i][j].setToolTipText("CurrentHP: "+champ.getCurrentHP());				

					}
					else if(champ.getName().equals("Quicksilver")) {
						boardV[i][j].setIcon(new ImageIcon("Quicksilver.png"));
						boardV[i][j].setToolTipText("CurrentHP: "+champ.getCurrentHP());				

					}
					else if(champ.getName().equals("Spiderman")) {
						boardV[i][j].setIcon(new ImageIcon("Spiderman.png"));
						boardV[i][j].setToolTipText("CurrentHP: "+champ.getCurrentHP());				

					}
					
					else if(champ.getName().equals("Thor")) {
						boardV[i][j].setIcon(new ImageIcon("Thor.jpg"));
						boardV[i][j].setToolTipText("CurrentHP: "+champ.getCurrentHP());				

					}
					else if(champ.getName().equals("Venom")) {
						boardV[i][j].setIcon(new ImageIcon("Venom.png"));
						boardV[i][j].setToolTipText("CurrentHP: "+champ.getCurrentHP());				

					}
					else if(champ.getName().equals("Yellow Jacket")) {
						boardV[i][j].setIcon(new ImageIcon("YellowJacket.png"));
						boardV[i][j].setToolTipText("CurrentHP: "+champ.getCurrentHP());				

					}
					
					
					if(MainJframe.getGame().getFirstPlayer().getTeam().contains(champ)) {
						boardV[i][j].setBackground(Color.BLUE);

					}
					else if(MainJframe.getGame().getSecondPlayer().getTeam().contains(champ)) {
						boardV[i][j].setBackground(Color.RED);

					}
					Champion o=	(Champion) MainJframe.getGame().getTurnOrder().peekMin();
					if(champ == o) {
						boardV[i][j].setBackground(Color.GREEN);

					}

				}
			}
		}
		
	
			}
	
	
	@Override
	public void actionPerformed(ActionEvent e) {
		for(int i=0; i<5; i++) {
			for(int j=0; j<5 ;j++) {
				if(e.getSource()==boardV[i][j]) {
					if(MainJframe.getGame().getBoard()[i][j] instanceof Champion) {
						Champion c= (Champion) MainJframe.getGame().getBoard()[i][j];
						String s = gamePanel.getChampAllinfo(c);
						gamePanel.getAllRemChampTArea().setText(s);
				}
				}
				
			}
		}
	}


	public JButton[][] getBoardV() {
		return boardV;
	}


	public void setBoardV(JButton boardV[][]) {
		this.boardV = boardV;
	}

}
