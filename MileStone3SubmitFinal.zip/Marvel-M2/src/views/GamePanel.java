package views;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

import engine.PriorityQueue;
import exceptions.AbilityUseException;
import exceptions.ChampionDisarmedException;
import exceptions.InvalidTargetException;
import exceptions.LeaderAbilityAlreadyUsedException;
import exceptions.LeaderNotCurrentException;
import exceptions.NotEnoughResourcesException;
import exceptions.UnallowedMovementException;
import model.abilities.Ability;
import model.abilities.AreaOfEffect;
import model.abilities.CrowdControlAbility;
import model.abilities.DamagingAbility;
import model.abilities.HealingAbility;
import model.effects.Effect;
import model.world.AntiHero;
import model.world.Champion;
import model.world.Direction;
import model.world.Hero;
import model.world.Villain;

public class GamePanel extends JPanel implements ActionListener {

	private MainJFrame MainJframe; 
	private BoardPanel boardPanel;

	private JTextArea CurrTArea;
	private JScrollPane scroll1;
	
	private JTextArea AllRemChampTArea;
	private JScrollPane scroll2;
	
	private JLabel fplabel;
	private JLabel splabel;
	
	private JButton fpColorlabel;
	private JButton spColorlabel;
	
	private JLabel CurrPDetailsLabel;
	private JLabel RemainingPdetailsLabel;
	
	private JButton upButton;
	private JButton downButton;
	private JButton leftButton;
	private JButton rightButton;
	
	private JButton moveButton;
	private JButton attackButton;

	private Integer [] u = {0,1,2,3,4,};
	private JComboBox <Integer> xCord;
	private JComboBox <Integer>  yCord;
	private JComboBox <String> ChampAbilities;
	
	private JLabel xCordLabel;
	private JLabel yCordLabel;
	

	private JButton CastAbilityButton;
	private JButton LeaderAbilityButton;
	private JButton EndTurnButton;
	
	private JTextArea turnOrderArea;
	private JScrollPane scroll3; 
	
	private Direction direction;


	private JLabel CurrLabel;
	
	private JLabel Leader1AbilityLabel;
	private JLabel Leader2AbilityLabel;

	private String L1;
	private String L2;

	
	
	public GamePanel(MainJFrame MainJframe) {
		this.MainJframe= MainJframe;
		
		this.setVisible(true);
		this.setLayout(null);
		this.setBackground(Color.LIGHT_GRAY);
		
		
		
		
		boardPanel = new BoardPanel(MainJframe,this);
		boardPanel.setBounds(250, 100 , 500, 500);
		this.add(boardPanel);
				

		CurrTArea= new JTextArea();
		CurrTArea.setEditable(false);
		String s = getAllChamInfoFinal(MainJframe);
		CurrTArea.setText(s);
		scroll1=new JScrollPane(CurrTArea);
		scroll1.setBounds(30, 30, 200, 170);
		this.add(scroll1);
		
		
		
		AllRemChampTArea= new JTextArea("Click on any Champion to details");
		getAllRemChampTArea().setEditable(false);
		scroll2 = new JScrollPane(AllRemChampTArea);
		scroll2.setBounds(760, 30, 200, 170);
		this.add(scroll2);
		
		
		String fname= MainJframe.getGame().getFirstPlayer().getName();
		fplabel = new JLabel("First Player: " + fname );
		fplabel.setBounds(400, 60, 200, 30);
		this.add(fplabel);
		fplabel.setBackground(Color.BLACK);
		fplabel.setForeground(Color.WHITE);
		
		fpColorlabel = new JButton();
		fpColorlabel.setBounds(360, 60, 30, 30);
		fpColorlabel.setBackground(Color.BLUE);
		this.add(fpColorlabel);
		
		
		
		String sname= MainJframe.getGame().getSecondPlayer().getName();
		splabel = new JLabel("Second Player: " + sname);
		splabel.setBounds(400, 610, 200, 30);
		this.add(splabel);
		splabel.setBackground(Color.BLACK);
		splabel.setForeground(Color.WHITE);
		
		spColorlabel = new JButton();
		spColorlabel.setBounds(360, 610, 30, 30);
		spColorlabel.setBackground(Color.RED);
		this.add(spColorlabel);
		
		
		CurrPDetailsLabel = new JLabel("Current Player's Details: ");
		CurrPDetailsLabel.setBounds(30, 10, 200, 20);
		this.add(CurrPDetailsLabel);
		CurrPDetailsLabel.setBackground(Color.BLACK);
		CurrPDetailsLabel.setForeground(Color.WHITE);
		
		RemainingPdetailsLabel = new JLabel("Remaining Players' Details: ");
		RemainingPdetailsLabel.setBounds(760, 10, 200, 20);
		this.add(RemainingPdetailsLabel);
		RemainingPdetailsLabel.setBackground(Color.BLACK);
		RemainingPdetailsLabel.setForeground(Color.WHITE);
		
		upButton= new JButton();
		upButton.setIcon(new ImageIcon("up.png"));
		upButton.setBounds(70, 210, 50, 50);
		this.add(upButton);
		upButton.addActionListener(this);
		
		
		downButton= new JButton();
		downButton.setIcon(new ImageIcon("down.png"));
		downButton.setBounds(70, 330, 50, 50);
		this.add(downButton);
		downButton.addActionListener(this);

		
		leftButton= new JButton();
		leftButton.setIcon(new ImageIcon("left.png"));
		leftButton.setBounds(40, 270, 50, 50);
		this.add(leftButton);
		leftButton.addActionListener(this);

		
		rightButton= new JButton();
		rightButton.setIcon(new ImageIcon("right.png"));
		rightButton.setBounds(100, 270, 50, 50);
		this.add(rightButton);
		rightButton.addActionListener(this);

		
		moveButton= new JButton("MOVE");
		moveButton.setBounds(60, 400, 100, 40);
		this.add(moveButton);
		moveButton.addActionListener(this);
		moveButton.setBackground(Color.BLACK);
		moveButton.setForeground(Color.WHITE);

		
		attackButton= new JButton("ATTACK");
		attackButton.setBounds(60, 450, 100, 40);
		this.add(attackButton);
		attackButton.addActionListener(this);
		attackButton.setBackground(Color.BLACK);
		attackButton.setForeground(Color.WHITE);
		
		EndTurnButton= new JButton("EndTurn");
		EndTurnButton.setBounds(60, 500, 100, 40);
		this.add(EndTurnButton);
		EndTurnButton.addActionListener(this);
		EndTurnButton.setBackground(Color.BLACK);
		EndTurnButton.setForeground(Color.WHITE);

		
		turnOrderArea= new JTextArea();
		turnOrderArea.setEditable(false);
		String j = getOrderOfChampsinTurnOrder();
		turnOrderArea.setText(j);
		scroll3= new JScrollPane(turnOrderArea);
		scroll3.setBounds(60, 550, 150 , 100);
		this.add(scroll3);

	
		
		

		
		xCord = new JComboBox<Integer>(u);
		xCord.setBounds(780, 250, 50 , 50);
		this.add(xCord);
		
		
		xCordLabel = new JLabel("X-Coordinate");
		xCordLabel.setBounds(780, 230, 200, 15);
		this.add(xCordLabel);
		
		yCord = new JComboBox<Integer>(u);
		yCord.setBounds(880, 250, 50 , 50);
		this.add(yCord);
		
		
		yCordLabel = new JLabel("Y-Coordinate");
		yCordLabel.setBounds(880, 230, 200, 15);
		this.add(yCordLabel);
		
		ChampAbilities= new JComboBox<String>();
		ChampAbilities.setBounds(780, 330, 150, 50);
		this.add(ChampAbilities);
		updateAbilityOfCurrChampCombo();

		
		
		CastAbilityButton= new JButton("Cast Ability");
		CastAbilityButton.setBounds(780, 390, 150, 50);
		this.add(CastAbilityButton);
		CastAbilityButton.addActionListener(this);
		CastAbilityButton.setBackground(Color.BLACK);
		CastAbilityButton.setForeground(Color.WHITE);


		
		LeaderAbilityButton= new JButton("Leader Ability");
		LeaderAbilityButton.setBounds(780, 450, 150, 50);
		this.add(LeaderAbilityButton);
		LeaderAbilityButton.addActionListener(this);
		LeaderAbilityButton.setBackground(Color.BLACK);
		LeaderAbilityButton.setForeground(Color.WHITE);
		
		L1= MainJframe.getGame().getFirstPlayer().getName();
		Leader1AbilityLabel= new JLabel(L1+": NOT USED");
		Leader1AbilityLabel.setBounds(780, 515, 150, 30);
		this.add(Leader1AbilityLabel);
		
		L2= MainJframe.getGame().getSecondPlayer().getName();
		Leader2AbilityLabel= new JLabel(L2+": NOT USED");
		Leader2AbilityLabel.setBounds(780, 555, 150, 30);
		this.add(Leader2AbilityLabel);
		
		
		
		
		
		CurrLabel= new JLabel();
		String o = isCurrentPlayingLabel();
		CurrLabel.setText(o);   
		CurrLabel.setBackground(Color.BLACK);
		CurrLabel.setForeground(Color.GREEN);
		CurrLabel.setOpaque(true);
		CurrLabel.setBounds(760, 600, 215, 50);
		CurrLabel.setFont(new Font("Serif",Font.BOLD,15));
		this.add(CurrLabel);
		
		

		
		
		
	}

	private String getAllChamInfoFinal(MainJFrame MainJframe) {
		Champion c = (Champion) MainJframe.getGame().getTurnOrder().peekMin();
		String s = getChampAllinfo(c);
		return s;
	}

	public String getChampAllinfo(Champion c) {
		String s= "Name: "+ c.getName() + "\n" + "MaxHP: " + c.getMaxHP() +"\n" +"CurrentHP: " + c.getCurrentHP() +"\n" +
				"Mana: " + c.getMana()+"\n" + "maxActionPointsPerTurn: " + c.getMaxActionPointsPerTurn()+"\n" +
				"currentActionPoints: " + c.getCurrentActionPoints() +"\n" + "attackRange: "+ c.getAttackRange() +"\n" +
				"attackDamage: "+c.getAttackDamage()+"\n" + 
				"speed: "+c.getSpeed()+"\n"+ "Type: ";
		if(c instanceof AntiHero) {
			s=s+ "AntiHero \n";
		}
		else if(c instanceof Hero) {
			s=s+ "Hero \n";
		}
		else if(c instanceof Villain) {
			s=s+ "Villain \n";

		}
		if(MainJframe.getfirstPlayerLeader()==c) {
			s=s+"is Leader of First Team  \n\n";
		}
		else if(MainJframe.getsecondPlayerLeader()==c) {
			s=s+"is Leader of the Second Team \n\n";
		}
		else {
			s=s+"is Not Leader \n\n";
		}

		
		s=s+ "Abilities: " + "\n" ;
		for(int i=1; i<4;i++) {
			Ability a = c.getAbilities().get(i-1);
			s= s + i+ ")" +a.getName() + ":- " + "\n"+ "type:  " ; 
			if(a instanceof CrowdControlAbility) {
				s=s+ "CrowdControlAbility" + "\n"; 
			}
			else if(a instanceof HealingAbility) {
				s=s+ "HealingAbility"+ "\n"; 
			}
			else if(a instanceof DamagingAbility) {
				s=s+ "DamagingAbility" + "\n"; 
			} 
			
			s=s+ "area of affect: " + a.getCastArea() + "\n" + "cast range: " + a.getCastRange() + "\n" + 
			"ManaCost: " + a.getManaCost() + "\n" + "requiredActionPoints: " + a.getRequiredActionPoints()
			+ "\n" + "CurrentCoolDown: "+ a.getCurrentCooldown()+ "\n" + "BaseCoolDown: "+ a.getBaseCooldown()
			+ "\n" ;
			if(a instanceof CrowdControlAbility) {
				s=s+ "Effect Name: " + ((CrowdControlAbility) a).getEffect().getName() + "\n" +"Effect Duration: "+
				((CrowdControlAbility) a).getEffect().getDuration() + "\n\n"; 
			}
			else if(a instanceof HealingAbility) {
				s=s+ "Healing Amount: " + ((HealingAbility) a).getHealAmount()+ "\n\n"; 
			}
			else if(a instanceof DamagingAbility) {
				s=s+ "Damage Amount: " + ((DamagingAbility) a).getDamageAmount()+ "\n\n"; 
			}
		}
		s=s+ "Applied Effects: \n";
		for(int i=1;i<((c.getAppliedEffects().size())+1); i++) {

		Effect e= c.getAppliedEffects().get(i-1);

		s=s+i+")"+"Effect Name: " + e.getName() +"\n" +"Effect Duration: " + e.getDuration()+"\n";
			
		}

		return s;
	}

	public JTextArea getAllRemChampTArea() {
		return AllRemChampTArea;
	}

	public void setAllRemChampTArea(JTextArea allRemChampTArea) {
		AllRemChampTArea = allRemChampTArea;
	}

	@Override
	public void actionPerformed(ActionEvent e) {

		if(e.getSource()==rightButton) {
			direction= Direction.RIGHT;
		}
		else if(e.getSource()==leftButton) {
			direction= Direction.LEFT;
		}
		else if(e.getSource()==downButton) {
			direction= Direction.UP;
		}
		else if(e.getSource()==upButton) {
			direction= Direction.DOWN;
		}
		
		
		
		if(e.getSource()==moveButton) {
			try {
				MainJframe.getGame().move(direction);
				attackHRefactor();
				
			} catch (NotEnoughResourcesException e1) {
				JOptionPane.showMessageDialog(this, e1, "ERROR", JOptionPane.ERROR_MESSAGE);
			} catch (UnallowedMovementException e1) {
				JOptionPane.showMessageDialog(this, e1, "ERROR", JOptionPane.ERROR_MESSAGE);
			}
			
		}
		else if (e.getSource()==attackButton) {
			try {
				MainJframe.getGame().attack(direction);
				attackHRefactor();
				if(MainJframe.getGame().checkGameOver()==MainJframe.getGame().getFirstPlayer()) {
					JOptionPane.showMessageDialog(this, MainJframe.getGame().getFirstPlayer().getName() +
							" WON!!","Game Over", JOptionPane.INFORMATION_MESSAGE);
					MainJframe.dispose();
				}
				
				
				else if(MainJframe.getGame().checkGameOver()==MainJframe.getGame().getSecondPlayer()) {
					JOptionPane.showMessageDialog(this, MainJframe.getGame().getSecondPlayer().getName() +
							" WON!!","Game Over", JOptionPane.INFORMATION_MESSAGE);
					MainJframe.dispose();

				}
				
			} catch (NotEnoughResourcesException e1) {
				JOptionPane.showMessageDialog(this, e1, "ERROR", JOptionPane.ERROR_MESSAGE);
			} catch (ChampionDisarmedException e1) {
				JOptionPane.showMessageDialog(this, e1, "ERROR", JOptionPane.ERROR_MESSAGE);
			} catch (InvalidTargetException e1) {
				JOptionPane.showMessageDialog(this, e1, "ERROR", JOptionPane.ERROR_MESSAGE);
			}
			
		}
		else if(e.getSource()==EndTurnButton) {
			MainJframe.getGame().endTurn();
			endTurnHRefactor();
			
		}
		else if (e.getSource()== CastAbilityButton) {
			int x = ChampAbilities.getSelectedIndex();
			Champion c = (Champion)(MainJframe.getGame().getTurnOrder().peekMin());
			Ability a = c.getAbilities().get(x);
			
			if(a.getCastArea()== AreaOfEffect.DIRECTIONAL) {
				try {
					MainJframe.getGame().castAbility(a, direction);
				} catch (NotEnoughResourcesException e1) {
					JOptionPane.showMessageDialog(this, e1, "ERROR", JOptionPane.ERROR_MESSAGE);
				} catch (AbilityUseException e1) {
					JOptionPane.showMessageDialog(this, e1, "ERROR", JOptionPane.ERROR_MESSAGE);

				} catch (CloneNotSupportedException e1) {
					JOptionPane.showMessageDialog(this, e1, "ERROR", JOptionPane.ERROR_MESSAGE);

				}
				
			}
			else if (a.getCastArea()== AreaOfEffect.SELFTARGET || a.getCastArea()== AreaOfEffect.SURROUND 
					|| a.getCastArea()== AreaOfEffect.TEAMTARGET){
				try {
					MainJframe.getGame().castAbility(a);
				} catch (NotEnoughResourcesException e1) {
					JOptionPane.showMessageDialog(this, e1, "ERROR", JOptionPane.ERROR_MESSAGE);

				} catch (AbilityUseException e1) {
					JOptionPane.showMessageDialog(this, e1, "ERROR", JOptionPane.ERROR_MESSAGE);

				} catch (CloneNotSupportedException e1) {
					JOptionPane.showMessageDialog(this, e1, "ERROR", JOptionPane.ERROR_MESSAGE);

				}
				
			}
			else if (a.getCastArea()== AreaOfEffect.SINGLETARGET) {
				int x1 =xCord.getSelectedIndex();
				int x_Cord = u[x1];
				int y1 =yCord.getSelectedIndex();
				int y_Cord = u[y1];
				try {
					MainJframe.getGame().castAbility(a, x_Cord, y_Cord);
				} catch (NotEnoughResourcesException e1) {
					JOptionPane.showMessageDialog(this, e1, "ERROR", JOptionPane.ERROR_MESSAGE);

				} catch (AbilityUseException e1) {
					JOptionPane.showMessageDialog(this, e1, "ERROR", JOptionPane.ERROR_MESSAGE);

				} catch (InvalidTargetException e1) {
					JOptionPane.showMessageDialog(this, e1, "ERROR", JOptionPane.ERROR_MESSAGE);

				} catch (CloneNotSupportedException e1) {
					JOptionPane.showMessageDialog(this, e1, "ERROR", JOptionPane.ERROR_MESSAGE);

				}
			}
			attackHRefactor();
		}
		else if (e.getSource()== LeaderAbilityButton) {
			try {

				MainJframe.getGame().useLeaderAbility();
				useLeaderAbilityHRefactor();

				if(MainJframe.getGame().isFirstLeaderAbilityUsed()) {
					Leader1AbilityLabel.setText(L1+": USED");
				}
				if(MainJframe.getGame().isSecondLeaderAbilityUsed()) {
					Leader2AbilityLabel.setText(L2+": USED");
				}
				
			}
			
				catch (LeaderNotCurrentException e1) {
				JOptionPane.showMessageDialog(this, e1, "ERROR", JOptionPane.ERROR_MESSAGE);
			} catch (LeaderAbilityAlreadyUsedException e1) {
				JOptionPane.showMessageDialog(this, e1, "ERROR", JOptionPane.ERROR_MESSAGE);
			}
			
		}
	}

	private void attackHRefactor() {
		boardPanel.updatedBoard(MainJframe);
		String p = getAllChamInfoFinal(MainJframe);
		CurrTArea.setText(p);
	}

	private void useLeaderAbilityHRefactor() {
		String p = getAllChamInfoFinal(MainJframe);
		CurrTArea.setText(p);
		boardPanel.updatedBoard(MainJframe);
	}

	private void endTurnHRefactor() {
		String s = getAllChamInfoFinal(MainJframe);
		CurrTArea.setText(s);
		updateAbilityOfCurrChampCombo();
		String j = getOrderOfChampsinTurnOrder();
		turnOrderArea.setText(j);	
		boardPanel.updatedBoard(MainJframe);
		String o = isCurrentPlayingLabel();
		CurrLabel.setText(o);
	}

/*	private void checkifLeaderUsedAbility(Champion c) {
		if(MainJframe.getGame().isFirstLeaderAbilityUsed()==true &&
			MainJframe.getGame().getSecondPlayer().getTeam().contains(c) &&
			MainJframe.getGame().isSecondLeaderAbilityUsed()==false) {
		LeaderAbilityButton.setText("Leader Ability");

		}
		else if (MainJframe.getGame().isFirstLeaderAbilityUsed()==true &&
				MainJframe.getGame().getFirstPlayer().getTeam().contains(c)) {
			LeaderAbilityButton.setText("Leader Ability XXX");

		}
		else if(MainJframe.getGame().isSecondLeaderAbilityUsed()==true &&
				MainJframe.getGame().getFirstPlayer().getTeam().contains(c) && 
				MainJframe.getGame().isFirstLeaderAbilityUsed()==false) {
			LeaderAbilityButton.setText("Leader Ability");
		}
		else if (MainJframe.getGame().isSecondLeaderAbilityUsed()==true &&
				MainJframe.getGame().getSecondPlayer().getTeam().contains(c)) {
			LeaderAbilityButton.setText("Leader Ability XXX");

		}
	}
	*/
	
	public String [] getStringArrayofAbilitiesOfCurrCham() {
		Champion v = (Champion) MainJframe.getGame().getTurnOrder().peekMin();
		String [] h = new String [3];
		for(int i=0; i<v.getAbilities().size();i++) {
			h[i] = v.getAbilities().get(i).getName();
		}
		return h;
		}
	
	public void updateAbilityOfCurrChampCombo() {
		ChampAbilities.removeAllItems();
		String [] h = getStringArrayofAbilitiesOfCurrCham();
		for(int i=0; i<h.length;i++) {
			String b =h[i];
			ChampAbilities.addItem(b);

		}
	}



	public String getOrderOfChampsinTurnOrder() {
		PriorityQueue p = MainJframe.getGame().getTurnOrder();

		ArrayList <Champion> c = new ArrayList <Champion>();
		while(!p.isEmpty()) {
			c.add((Champion) p.remove());
		}
		for(int i=0;i<c.size();i++) {
			p.insert(c.get(i));
		}
		
		String s = "Order of Champions: \n";

		for(int i=1; i<((c.size())+1);i++) {
			s=s+i+") "+c.get(i-1).getName() + "\n";
		}
		return s;
	}
	
	public String isCurrentPlayingLabel() {
		Champion b = (Champion) MainJframe.getGame().getTurnOrder().peekMin();
		String h="";
		if(MainJframe.getGame().getFirstPlayer().getTeam().contains(b)) {
			h = "Currently Playing: " + (MainJframe.getGame().getFirstPlayer().getName());
			
		}
		else if( MainJframe.getGame().getSecondPlayer().getTeam().contains(b)) {
			 h = "Currently Playing: " + (MainJframe.getGame().getSecondPlayer().getName());

		}
		return h;
	}
	


	
}