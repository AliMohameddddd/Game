package views;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.IOException;
import java.util.ArrayList;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import engine.Game;
import model.abilities.Ability;
import model.abilities.CrowdControlAbility;
import model.abilities.DamagingAbility;
import model.abilities.HealingAbility;
import model.world.Champion;

public class FirstPlayerPanel extends JPanel implements ActionListener, ListSelectionListener {

	private JLabel fPLabel;
	private JTextField fPField;
	private JList <String> fPList;
	private JButton fPButton;
	private JCheckBox fPCheck1;
	private JCheckBox fPCheck2;
	private JCheckBox fPCheck3;
	private ButtonGroup fPBGroup;
	private JTextArea fPArea;
	private JScrollPane s; 
	
	private MainJFrame MainJframe;
	
	private SecondPlayerPanel secondPlayerPanel;
	
	

	
	public FirstPlayerPanel(MainJFrame MainJframe) {
		
		this.MainJframe=MainJframe;
		
		this.setVisible(true);
		this.setLayout(null);
		this.setBackground(Color.BLACK);
		
		
		fPLabel = new JLabel("First Player Name:");
		fPLabel.setBounds(50, 140, 150, 35);
		this.add(fPLabel);
		fPLabel.setForeground(Color.WHITE);
		
		
		fPField = new JTextField();
		fPField.setBounds(250, 140, 150, 35);
		this.add(fPField);
		
		fPButton = new JButton("Next->");
		fPButton.setBounds(520, 530, 150, 35);
		fPButton.setFont(new Font("Serif",Font.BOLD,15));
		this.add(fPButton);
		fPButton.addActionListener(this);
		
		fPCheck1 = new JCheckBox("1st selection will be leader");
		fPCheck1.setBackground(Color.BLACK);
		fPCheck1.setForeground(Color.WHITE);
		fPCheck1.setBounds(780, 110, 190, 20);
		this.add(fPCheck1);
		
		fPCheck2 = new JCheckBox("2nd selection will be leader");
		fPCheck2.setBackground(Color.BLACK);
		fPCheck2.setForeground(Color.WHITE);
		fPCheck2.setBounds(780, 260, 200, 20);
		this.add(fPCheck2);
		
		fPCheck3 = new JCheckBox("3rd selection will be leader");
		fPCheck3.setBackground(Color.BLACK);
		fPCheck3.setForeground(Color.WHITE);
		fPCheck3.setBounds(780, 410, 190, 20);
		this.add(fPCheck3);
		
		fPBGroup = new ButtonGroup();
		fPBGroup.add(fPCheck1);
		fPBGroup.add(fPCheck2);
		fPBGroup.add(fPCheck3);
		
		fPArea = new JTextArea("please select a champion from the list");
		fPArea.setEditable(false);
		s= new JScrollPane(fPArea);
		s.setBounds(50, 280, 300, 300);
		this.add(s);
		//fPArea.setBounds(50, 280, 300, 200);
		// this.add(fPArea);
		
		MainJframe.getavailableChampions();
		String [] availableChampionsA = MainJframe.getAvailableChampionsA();
		fPList = new JList <String>(availableChampionsA);
		fPList.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
		fPList.setBounds(450, 70, 300, 420);
		fPList.addListSelectionListener(this); 
		this.add(fPList);
		
		
	
	
		
		
	}
	
	

	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==fPButton) {
		if(fPField.getText().equals("")) {
			JOptionPane.showMessageDialog(this, "please enter a player name", "ERROR",
					JOptionPane.ERROR_MESSAGE);	
		}
		else if ((fPList.getSelectedIndices().length)!=3) {
			JOptionPane.showMessageDialog(this, "Please select 3 Champions", "ERROR",
					JOptionPane.ERROR_MESSAGE);
		}
		
		else if (fPCheck1.isSelected()==false && fPCheck2.isSelected()==false && fPCheck3.isSelected()==false) {
			JOptionPane.showMessageDialog(this, "Please select one Champion as a leader", "ERROR",
					JOptionPane.ERROR_MESSAGE);
			
		}
		else {
			
			MainJframe.setFirstPlayerName(fPField.getText());
			MainJframe.firstPlayerTeamOfChampsMethod(fPList.getSelectedIndices());
			if(fPCheck1.isSelected()) {
				int index = fPList.getSelectedIndices()[0];
				MainJframe.setFLeader(MainJframe.getAvailableChampionsA()[index]);
			}
			else if(fPCheck2.isSelected()) {
				int index = fPList.getSelectedIndices()[1];
				MainJframe.setFLeader(MainJframe.getAvailableChampionsA()[index]);
			}
			else if(fPCheck3.isSelected()) {
				int index = fPList.getSelectedIndices()[2];
				MainJframe.setFLeader(MainJframe.getAvailableChampionsA()[index]);
			}
			
			switchToSecondPlayerPanel();
			
			
		}
		}
		
		}
	public void switchToSecondPlayerPanel() {
		
		this.setVisible(false);
		
		secondPlayerPanel= new SecondPlayerPanel(MainJframe);
		MainJframe.add(secondPlayerPanel);

		this.validate();
		this.repaint();
		
		
	}



	@Override
	public void valueChanged(ListSelectionEvent e) {
			int index = fPList.getAnchorSelectionIndex();
			ArrayList <Champion> list = Game.getAvailableChampions();
			Champion c = list.get(index);
			
		
		/*	String s= "Name: "+ c.getName() + "\n" + "MaxHP: " + c.getMaxHP() +"\n" +"CurrentHP" + c.getCurrentHP() +"\n" +
					"Mana: " + c.getMana()+"\n" + "maxActionPointsPerTurn: " + c.getMaxActionPointsPerTurn()+"\n" +
					"currentActionPoints: " + c.getCurrentActionPoints() +"\n" + "attackRange: "+ c.getAttackRange() +"\n" +
					"attackDamage: "+c.getAttackDamage()+"\n" + 
					"speed: "+c.getSpeed()+"\n\n" + "Abilities: " + "\n" ;
			for(int i=1; i<4;i++) {
				Ability a = c.getAbilities().get(i-1);
				s= s + (i)+ ")" +a.getName() + ":- " + "\n"+ "type:  " ; 
				if(a instanceof CrowdControlAbility) {
					s=s+ "CrowdControlAbility" + "\n"; 
				}
				else if(a instanceof HealingAbility) {
					s=s+ "HealingAbility"+ "\n"; 
				}
				else if(a instanceof DamagingAbility) {
					s=s+ "DamagingAbility" + "\n"; 
				} 
				
				s=s+ "area of affect: " + a.getCastArea() + "\n" + "cast range: " + a.getCastRange() + "\n" + 
				"ManaCost: " + a.getManaCost() + "\n" + "requiredActionPoints: " + a.getRequiredActionPoints()
				+ "\n" + "CurrentCoolDown: "+ a.getCurrentCooldown()+ "\n" + "BaseCoolDown: "+ a.getBaseCooldown()
				+ "\n" ;
				if(a instanceof CrowdControlAbility) {
					s=s+ "Effect Name: " + ((CrowdControlAbility) a).getEffect().getName() + ", Effect Duration: "+
					((CrowdControlAbility) a).getEffect().getDuration() + "\n\n"; 
				}
				else if(a instanceof HealingAbility) {
					s=s+ "Healing Amount: " + ((HealingAbility) a).getHealAmount()+ "\n\n"; 
				}
				else if(a instanceof DamagingAbility) {
					s=s+ "Damage Amount: " + ((DamagingAbility) a).getDamageAmount()+ "\n\n"; 
				}
				
			} */
			
			String s= "Name: "+ c.getName() + "\n" + "MaxHP: " + c.getMaxHP() +"\n" +"CurrentHP" + c.getCurrentHP() +"\n" +
					"Mana: " + c.getMana()+"\n" + "maxActionPointsPerTurn: " + c.getMaxActionPointsPerTurn()+"\n" +
					"currentActionPoints: " + c.getCurrentActionPoints() +"\n" + "attackRange: "+ c.getAttackRange() +"\n" +
					"attackDamage: "+c.getAttackDamage()+"\n" + 
					"speed: "+c.getSpeed()+"\n\n" + "Abilities: " + "\n" ;
			
			for(int i=1; i<4;i++) {
				Ability a = c.getAbilities().get(i-1);
				s= s + i+ ")" +a.getName() + ":- " + "\n"+ "type:  " ; 
				if(a instanceof CrowdControlAbility) {
					s=s+ "CrowdControlAbility" + "\n"; 
				}
				else if(a instanceof HealingAbility) {
					s=s+ "HealingAbility"+ "\n"; 
				}
				else if(a instanceof DamagingAbility) {
					s=s+ "DamagingAbility" + "\n"; 
				} 
				
				s=s+ "area of affect: " + a.getCastArea() + "\n" + "cast range: " + a.getCastRange() + "\n" + 
				"ManaCost: " + a.getManaCost() + "\n" + "requiredActionPoints: " + a.getRequiredActionPoints()
				+ "\n" + "CurrentCoolDown: "+ a.getCurrentCooldown()+ "\n" + "BaseCoolDown: "+ a.getBaseCooldown()
				+ "\n" ;
				if(a instanceof CrowdControlAbility) {
					s=s+ "Effect Name: " + ((CrowdControlAbility) a).getEffect().getName() + "\n" +"Effect Duration: "+
					((CrowdControlAbility) a).getEffect().getDuration() + "\n\n"; 
				}
				else if(a instanceof HealingAbility) {
					s=s+ "Healing Amount: " + ((HealingAbility) a).getHealAmount()+ "\n\n"; 
				}
				else if(a instanceof DamagingAbility) {
					s=s+ "Damage Amount: " + ((DamagingAbility) a).getDamageAmount()+ "\n\n"; 
				}
			}
				
			
			fPArea.setText(s);
			}
		
		
	}
	
	















	
	
	
	
